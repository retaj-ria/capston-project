const login = async() => {

   let username = document.getElementById("inputusername").value;
   let password = document.getElementById("inputpassword").value;

   console.log({username,password})
    await axios
      .post("https://project1165.herokuapp.com/members/login",{username,password})
      .then(async(response) => {
        console.log(response.data)
        await sessionStorage.setItem('user',response?.data)
       window.location.href = './index.html'
      
      })
      .catch( (error) => {
        console.log(error);
        alert("error");
      });
    };

    const logOut  = async() => {

      // sessionStorage.clear()
       sessionStorage.removeItem('user');
       window.location.href = './index.html'
     }