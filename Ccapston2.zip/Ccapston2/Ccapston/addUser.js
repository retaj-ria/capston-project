const addUser = async () => {
  let username = document.getElementById("add_fn").value;
  let usersurname = document.getElementById("add_ln").value;
  let User_ID = document.getElementById("add_ui").value;
  let Card_ID = document.getElementById("cardbox").value;
  // let Doors = document.getElementById("Authorizationbox").children;
  var selected = [{}];
  for (var option of document.getElementById("Authorizationbox").options) {
    if (option.selected) {
      selected.push({ Rfid_ID: Card_ID, DoorID: option.value });
    }
  }
  // var auth = [Card_ID, Door_ID];
  // var auth = [Doors];
  var auth = selected;
  // console.log(username, usersurname, User_ID, Card_ID, auth);

  // Doors.forEach((element) => (
  //    console.log(element)

  //     auth.push({Card_ID,Door_ID:element );
  //    ))

  await axios
    .post("https://project1165.herokuapp.com/users/add", {
      username,
      usersurname,
      User_ID,
      Card_ID,
      auth: auth,
    })

    .then((response) => {
      console.log(response.data);
      if (response.data) {
        alert("User added refrech to see it");
      }
    })
    .catch((error) => {
      console.log(error);
      alert("error");
    });
};
