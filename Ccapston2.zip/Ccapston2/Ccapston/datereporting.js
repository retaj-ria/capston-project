const datereporting = async() => {

    let date = document.getElementById("add_fn").value;
    var tableref= document.getElementById("myTable1").getElementsByTagName("tbody")[0]
   

    console.log({date})
     await axios
       .post("https://project1165.herokuapp.com/history/reportingdate",{date})
       .then((response) => {
         console.log(response.data)
         let myData = response.data
         tableref.innerHTML= ""
     for(let i =0; i<myData.length;i++){
       var  mylist =`<td>${myData[i].userId.username}</td><td>${myData[i].userId.usersurname}</td><td>${myData[i].userId.User_ID}</td><td>${myData[i].Rfid_ID.Card_ID}</td><td>${myData[i].Door_ID.DoorName}</td><td>${myData[i].date}</td><td>${myData[i].time}</td>`
       var newRow = tableref.insertRow(tableref.rows.length);
       newRow.innerHTML = mylist;
     }
       })
       .catch( (error) => {
         console.log(error);
         alert("error");
       });
     };