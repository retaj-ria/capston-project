const addDoor = async() => {
 
    let Door_ID = document.getElementById("add_ln").value;
    let DoorName = document.getElementById("add_fn").value;

    console.log({Door_ID,DoorName})
     await axios
       .post("https://project1165.herokuapp.com/doors/add",{Door_ID,DoorName})
       .then((response) => {
         console.log(response.data)
         if(response.data){
         
          
        
             alert
            ("Data Added refrech to see it");  
         }
       })

      

        .catch( (error) => {
         console.log(error);
         alert("error");
       });

     };
     var myArray=[]

     axios.interceptors.response.use((response) => {
      // do something with the response data
      console.log('Response was received');
    
      return response;
    }, error => {
      // handle the response error
      return Promise.reject(error);
    });
 
    // sent a GET request
    axios.get('https://project1165.herokuapp.com/doors/getdoors?activeness=true ')
      .then(response => {
        console.log(response.data);
        myArray = response.data
        buildTable(myArray)
    
      });

      function buildTable(data){
        var table = document.getElementById('content')

        for (var i = 0; i < data.length; i++){
          var row = `<tr>

            <td>${data[i].DoorName}</td>
            <td>${data[i].Door_ID}</td>
            <td> 
            <button type='button' onclick='contantDelete(this,"${data[i]._id}");' class='btn btn-danger'>
            Delete</button>
            </td>  

          </tr>`
        
        table.innerHTML += row
        }
      }
      const contantDelete = async (ctl, _id) => {
        var isOk = confirm("Are You Sure To Delete This Contact ? ");
        if (isOk == true) {
          // delete
          await axios
            .post("https://project1165.herokuapp.com/doors/delete", { _id })
      
            .then((response) => {
              if (response.data) {
                $(ctl).parents("tr").remove();
              
              }
            })
            .catch((error) => {
              console.log(error);
              alert("error");
            });
        }
      };

   