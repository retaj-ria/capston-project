const addCard = async() => {

    let Card_ID = document.getElementById("add_fn").value;
    
 
    console.log({Card_ID})
     await axios
       .post("https://project1165.herokuapp.com/cards/add",{Card_ID})
       .then((response) => {
         console.log(response.data)
         if(response.data){
            alert("Card added refresh to see it"); 
         }
       })
       .catch( (error) => {
         console.log(error);
         alert("error");
       });
     };


     var myArray=[]

     axios.interceptors.response.use((response) => {
      // do something with the response data
      console.log('Response was received');
    
      return response;
    }, error => {
      // handle the response error
      return Promise.reject(error);
    });
 
    // sent a GET request
    axios.get('https://project1165.herokuapp.com/cards/listOfCards?Availability=true')
      .then(response => {
        console.log(response.data);
        myArray = response.data
        buildTable(myArray)
    
      });

      function buildTable(data){
        var table = document.getElementById('content')

        for (var i = 0; i < data.length; i++){
          var row = `<tr>

            <td>${data[i].Card_ID}</td>
           

          </tr>`
        
        table.innerHTML += row
        }
      }
      