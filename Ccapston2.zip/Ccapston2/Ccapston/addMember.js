const addMember = async() => {

    let username = document.getElementById("add_fn").value;
    let password = document.getElementById("add_ln").value;
    let type = document.getElementById("add_ui").value;
    
    console.log({username,password,type})
     await axios
       .post("https://project1165.herokuapp.com/members/add",{username,password,type})
       .then((response) => {
         console.log(response.data)
         if(response.data){
            alert("Member added refresh to see it "); 
         }
       })
       .catch( (error) => {
         console.log(error);
         alert("error");
       });
     };

    

      var myArray=[]

axios.interceptors.response.use((response) => {
 // do something with the response data
 console.log('Response was received');

 return response;
}, error => {
 // handle the response error
 return Promise.reject(error);
});

// sent a GET request
axios.get('https://project1165.herokuapp.com/members/listOfMembers')
 .then(response => {
   console.log(response.data);
   myArray = response.data
   buildTable(myArray)

 });

 function buildTable(data){
   var table = document.getElementById('content2')

   for (var i = 0; i < data.length; i++){
     var row = `<tr>

       <td>${data[i].username}</td>
       <td>${data[i].password}</td>
       <td>${data[i].type}</td>
       <td> 
        <button type='button' onclick='contantDelete(this,"${data[i]._id}");' class='btn btn-danger'>
       Delete</button>
       </td>  

     </tr>`
   
   table.innerHTML += row
   }
 }
 const contantDelete = async (ctl, _id) => {
  var isOk = confirm("Are You Sure To Delete This Contact ? ");
  if (isOk == true) {
    console.log('_id',_id)
    // delete
    await axios
      .post("https://project1165.herokuapp.com/members/delete", { id:_id })

      .then((response) => {
        if (response.data === null) {
          console.log(response)
          $(ctl).parents("tr").remove();
         /*  alert("ok"); */
        
        }
      })
      .catch((error) => {
        console.log(error);
        alert("error");
      });
  }
};

