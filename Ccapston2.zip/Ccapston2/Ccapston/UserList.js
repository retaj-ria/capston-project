var myArray = [];

axios.interceptors.response.use(
  (response) => {
    // do something with the response data
    console.log("Response was received");

    return response;
  },
  (error) => {
    // handle the response error
    return Promise.reject(error);
  }
);

// sent a GET request
axios
  .get("https://project1165.herokuapp.com/users/getUsers?user_archiving=false")
  .then((response) => {
    console.log(response.data);
    myArray = response.data;
    buildTable(myArray);
  });

function buildTable(data) {
  var table = document.getElementById("content2");
  for (var i = 0; i < data.length; i++) {
    var row = `<tr>

       <td>${data[i].username}</td>
       <td>${data[i].usersurname}</td>
       <td>${data[i].User_ID}</td>
       <td>${data[i].Card_ID.Card_ID}</td>
       <td> 
       <button type='button' onclick='contantDelete(this,"${data[i]._id}");' class='btn btn-danger'>
       <span class='glyphicon glyphicon-remove'/>
       Delete</button>
        
       </td>  

     </tr>`;
    table.innerHTML += row;
  }
}
const contantDelete = async (ctl, _id) => {
  var isOk = confirm("Are You Sure To Delete This Contact ? ");
  if (isOk == true) {
    // delete
    await axios
      .post("https://project1165.herokuapp.com/users/delete", { _id })

      .then((response) => {
        if (response.data) {
          $(ctl).parents("tr").remove();
          /* alert("ok"); */
        }
      })
      .catch((error) => {
        console.log(error);
        alert("error");
      });
  }
};

var myArray1 = [];

axios.interceptors.response.use(
  (response) => {
    // do something with the response data
    console.log("Response was received");

    return response;
  },
  (error) => {
    // handle the response error
    return Promise.reject(error);
  }
);

// sent a GET request
axios
  .get("https://project1165.herokuapp.com/cards/listOfCards?Availability=true")
  .then((response) => {
    console.log(response.data);
    myArray1 = response.data;
    cardSelect(myArray1);
  });

function cardSelect(data) {
  var optionlist = document.getElementById("cardbox");
  for (var i = 0; i < data.length; i++) {
    optionlist +=
      "<option value='" + data[i]._id + "'>" + data[i].Card_ID + "</option>";
    /*     table.innerHTML += row */
  }
  document.getElementById("cardbox").innerHTML = optionlist;
}

var myArray2 = [];

axios.interceptors.response.use(
  (response) => {
    // do something with the response data
    console.log("Response was received");

    return response;
  },
  (error) => {
    // handle the response error
    return Promise.reject(error);
  }
);

// sent a GET request
axios
  .get("https://project1165.herokuapp.com/doors/getdoors?activeness=true ")
  .then((response) => {
    console.log(response.data);
    myArray2 = response.data;
    authoSelect(myArray2);
  });

function authoSelect(data) {
  var optionlist2 = document.getElementById("Authorizationbox");

  for (var i = 0; i < data.length; i++) {
    optionlist2 +=
      "<option value='" + data[i]._id + "'>" + data[i].DoorName + "</option>";
    /*     table.innerHTML += row */
  }
  document.getElementById("Authorizationbox").innerHTML = optionlist2;
}
